
Обновить на мастер ноде пакеты и установить библиотеки

```
sudo apt update && sudo apt upgrade -y
sudo apt install -y build-essential gcc g++ cmake libreadline-dev zlib1g-dev libssl-dev libxml2-dev libxslt1-dev python3-dev bison flex libapr1-dev libevent-dev libcurl4-openssl-dev libbz2-dev libyaml-dev libkrb5-dev libxerces-c-dev zlib1g-dev libreadline-dev libssl-dev pkg-config perl
```

Установить python зависимости на всех нодах:

```
sudo apt install -y python3-pip pip3 install psycopg2-binary  
pip3 install psutil
```

Создать пользователя gpadmin на всех нодах и зайти под ним (дальше все команды выполняются из-под него)

```
sudo adduser --home /home/gpadmin --shell /bin/bash gpadmin
sudo usermod -aG sudo gpadmin
sudo su gpadmin
```

Создать директорию

```
mkdir -p /opt/data
```

Для установки из исходников потребуется скопировать проект с гита, либо зарегаться на broadcom и скачать оттуда:
```
git clone https://github.com/greenplum-db/gpdb-archive.git
cd gpdb-archive
```

Проверить зависимости

```
./configure --prefix=/opt/data --with-python --with-libxml --with-gssapi --without-readline   (readline можно оставить, но функционально не имеет смысла, будет использоваться `libedit`)
```

Предварительно сгенерировать парсеры

```
cd src/backend/parser
bison -d gram.y -o gram.c
flex -o scan.c scan.l
```

Вернуться в /opt/gpdb-archive и запустить make сборки

```
make -j$(nproc) для использования всех потоков процессора или просто make (увеличивает время сборки)
```

Выполнить установку

```
sudo make install
```

Сделать архив greenplum  и раскидать его между worker-ами

```
tar -czvf greenplum-db.tar.gz data/
rsync -av 10.255.254.101:/opt/greenplum-db.tar.gz /opt
```

Распаковать архив
```
sudo tar -xzvf greenplum-db.tar.gz -C /opt
sudo chown -R gpadmin:gpadmin /opt/data/
```

Настроить окружение на всех нодах:

```
echo "export PATH=/opt/data/bin:\$PATH" >> ~/.bashrc
echo "export GPHOME=/opt/data" >> ~/.bashrc
echo "export LD_LIBRARY_PATH=/opt/data/lib:\$LD_LIBRARY_PATH" >> ~/.bashrc
echo "export PYTHONPATH=/opt/data/lib/python:\$PYTHONPATH" >> ~/.bashrc
source ~/.bashrc

******Данная команда только на мастере:******
echo "export COORDINATOR_DATA_DIRECTORY=/data/master/gpseg-1" >> ~/.bashrc
source ~/.bashrc
```

Создать директории для данных master для мастер ноды и primary для worker

```
sudo mkdir -p /data/master && sudo chown gpadmin:gpadmin /data/master
sudo mkdir -p /data/primary && sudo chown gpadmin:gpadmin /data/primary
```

Создать ssh подключение по ключу для этого на мастер ноде:

```
ssh-keygen -t rsa -b 4096
ssh-copy-id gpadmin@gp-master
ssh-copy-id gpadmin@gp-segment1
ssh-copy-id gpadmin@gp-segment2

Предварительно отредактировать файл /etc/hosts указав 
ip:gp-master
ip:gp-segment1
ip:gp-segment2
```

Создать хост файл кластера, для создания внутренней сети:

```
echo -e "gp-segment1\ngp-segment2" > /home/gpadmin/hostfile
```

Создать файл инициализации кластера /home/gpadmin/gpinitsystem_config:

```
Примерное содержание:

ARRAY_NAME="Greenplum Cluster"
SEG_PREFIX=gpseg
PORT_BASE=6000
declare -a DATA_DIRECTORY=(/data/primary /data/primary)
MASTER_HOSTNAME=gp-master
MASTER_DIRECTORY=/data/master
MASTER_PORT=5432
TRUSTED_SHELL=ssh
CHECK_POINT_SEGMENTS=8
ENCODING=UNICODE
```

На всех нодах отредактировать /etc/security/limits.conf, добавив в конец:

```
gpadmin soft nofile 65535
gpadmin hard nofile 65535
```

Провести инициализацию кластера используя полный путь к gpinitsystem:

```
/opt/data/bin/gpinitsystem -c /home/gpadmin/gpinitsystem_config -h /home/gpadmin/hostfile
```
