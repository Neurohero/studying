version: '3.8'
services:
  php-app:
    image: php:apache
    container_name: app
    ports: 
     - '80:80'
    restart: unless_stopped
    depends_on:
      - app-db
      - db-cache
    networks:
      - app-db-network
  
  app-db:
    image: postgres
    container_name: app_db
    restart: unless_stopped
     volumes:
       - '/opt/app-db/data:/app-db/data'
       - 'add-db-config:/app-db/config'
    environment:
      - 'POSTGRESS_PASSWORD=mysecretpassword'
    networks:
      - app-db-network
    
  db-cache:
    image: redis
    container_name: redis
    restart: unless_stopped
    networks:
      - app-db-network

volumes: 
  add-db-config:
networks:
  app-db-network:
    name: app-db-network
    drive: bridge