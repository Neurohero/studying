FROM ubuntu:22.04 AS builder
RUN apt update && apt install -y apache2
COPY /var/www/html /var/www/html
WORKDIR /var/www/html
FROM ubuntu:22.04
RUN apt update && apt install -y apache2
WORKDIR /var/www/html
COPY --from=builder /var/www/html/ .
COPY --from=builder /etc/apache2 /etc/apache2
EXPOSE 80
CMD ["/usr/sbin/apachectl", "-D", "FOREGROUND"]


FROM python:3.11-slim AS builder
RUN apt update && apt install -y gcc libpq-dev
WORKDIR /app
COPY requirements.txt /app
RUN pip install --no-cache-dir -r requirements.txt
COPY . /app
CMD ["python", "app.py"]