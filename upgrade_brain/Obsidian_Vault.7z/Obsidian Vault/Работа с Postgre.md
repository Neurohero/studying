**СОЗДАНИЕ ИНДЕКСОВ:**
CREATE INDEX CONCURRENTLY idx_ИМЯ_ТАБЛИЦЫ_ИМЯ КОЛОНКИ ON ИМЯ_СХЕМЫ.ИМЯ_ТАБЛИЦЫ (ИМЯ_КОЛОНКИ);

**СОЗДАНИЕ ПОЛЬЗОВАТЕЛЯ + ВКЛЮЧЕНИЕ В РОЛИ И ГРУППУ:**
CREATE USER kmendeleev WITH PASSWORD 'BId5G8';
ALTER GROUP vpn_users ADD USER kmendeleev; 
ALTER ROLE kmendeleev WITH SUPERUSER;

**Выдача прав:**
Для выдачи прав сперва сделать USAGE (выдается на каждую схему отдельно)
GRANT USAGE ON SCHEMA public TO fkp_reader;
Затем выдать GRANT (выдается на каждую схему отдельно)
GRANT SELECT ON ALL TABLES IN SCHEMA public TO fkp_reader;

**Удалить из группы:**
REVOKE postgres FROM имя_пользователя;

**Удалить роль:**
 ALTER ROLE kmendeleev NOSUPERUSER;

**Восстановление проблемных сегментов - при падении АДБ:**
-- Останавливаем кластер PG
gpstop -aMfast
gpstart -a
--- восстанавливаем сегменты
gprecoverseg -Fa
--- проверяем сегмент
gpstate -e
---  ребаланс сегментов
gprecoverseg -ra
--- проверяем сегмент
gpstate -e

**Создание дампа ролей с удаленной БД в локальный хост**
/usr/pgsql-14/bin/pg_dumpall -h k8s.supercode.ru -p 30438 -U rrbpm_super --roles-only > roles.sql

**Загрузка дампа ролей в локальную БД**
psql -U postgres -d postgres -f /home/kmendeleev/roles.sql

**Вывод размера удаленной БД**
sudo psql -h k8s.supercode.ru -U rrbpm_super -p 30432 -d postgres -c "SELECT pg_database.datname AS database_name, pg_size_pretty(pg_database_size(pg_database.datname)) AS size FROM pg_database ORDER BY pg_database_size

**Создание дампа удаленной БД**
pg_dump -h 10.137.54.46 -d postgres -U j_replicator -n journal_dc1 -F c -f journal_dc1.dump

**Посмотреть привилегии роли** **на базу данных**
SELECT datname, rolname, has_database_privilege(rolname, datname, 'CONNECT') AS can_connect, has_database_privilege(rolname, datname, 'TEMP') AS can_temp, has_database_privilege(rolname, datname, 'CREATE') AS can_create FROM pg_database, pg_roles WHERE rolname = 'kpd_function' AND datname = 'ice-warehouse';

**Снятие блокировки в gp_lock**
UPDATE journal.gp_lock
SET lock_status = false
WHERE id = 1;

**Восстановление дампа**
pg_restore -d postgres --schema=journal_dc1 /opt/backup/journal_dc1.dump
create schema journal_dc1;

**Вакуум фулл**
SELECT 'vacuum full ' ||  bdinspname || '.' || bdirelname || ';' FROM gp_toolkit.gp_bloat_diag;

**Запрос на поиск мертвых строк**
select n_dead_tup, schemaname, relname from pg_stat_all_tables order by n_dead_tup desc;

**Удаление бэкапа**
sudo pg_probackup-14 show -B /opt/backup

sudo pg_probackup-14 delete --instance dc2-nsud-db -B /opt/backup -i SPY6OP

**Узнать размер всех БД**
SELECT datname, pg_size_pretty(pg_database_size(datname)) 
FROM pg_database; 

**Узнать размер конкретной БД**
SELECT pg_size_pretty(pg_database_size('имя_базы_данных'));

**Проверить активные сессии**
select pid, usename AS username, datname AS database_name, state, query, query_start, state_change FROM pg_stat_activity WHERE state = 'active'

**CLICKHOUSE**
**Очистка системных таблиц и настройка ротирования логов:**

SELECT database, name AS table_name, formatReadableSize(total_bytes) AS size FROM system.tables WHERE database = 'system' ORDER BY total_bytes DESC;

ALTER TABLE system.query_thread_log MODIFY TTL event_time + INTERVAL 30 DAY;
ALTER TABLE system.asynchronous_metric_log MODIFY TTL event_time + INTERVAL 30 DAY;
ALTER TABLE system.query_log MODIFY TTL event_time + INTERVAL 30 DAY;

OPTIMIZE TABLE system.query_thread_log FINAL;
OPTIMIZE TABLE system.query_log FINAL;
OPTIMIZE TABLE system.asynchronous_metric_log FINAL;

ALTER TABLE system.metric_log MODIFY TTL event_time + INTERVAL 30 DAY;
ALTER TABLE system.part_log MODIFY TTL event_time + INTERVAL 30 DAY;

OPTIMIZE TABLE system.metric_log FINAL;
OPTIMIZE TABLE system.part_log FINAL;
