[prod_DB]
10.138.1.1
[dev_DB]
10.138.4.4
[prod_WEB]
10.138.2.2 
[prod_APP]
10.138.3.3
[prod_ALL:childer]
prod_DB
prod_WEB
prod_APP
[DB_ALL:children]
prod_DB
dev_DB
[prod_servers]
linux1 ansible_host=10.138.66.11