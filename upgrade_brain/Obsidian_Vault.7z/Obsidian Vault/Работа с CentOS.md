**Cent OS 8**

cd /etc/yum.repos.d/

sed -i 's/mirrorlist/#mirrorlist/g' /etc/yum.repos.d/CentOS-*

sed -i 's|#baseurl=http://mirror.centos.org|baseurl=http://vault.centos.org|g' /etc/yum.repos.d/CentOS-*

**Cent OS 7**

sed -i s/mirror.centos.org/vault.centos.org/g /etc/yum.repos.d/.repo 

sed -i s/^#.*baseurl=http/baseurl=http/g /etc/yum.repos.d/.repo 

sed -i s/^mirrorlist=http/#mirrorlist=http/g /etc/yum.repos.d/.repo