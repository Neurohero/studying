1. **Сперва установить helm**
	1. curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
2. **Для создания общей точки входа нужен ingress( установим Nginx)** 
	1. helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
	2. helm install ingress-nginx ingress-nginx/ingress-nginx
	3. kubectl get svc -n default (эта команда выведет внешний Ip адрес как точку входа)
3. **Добавить репозиторий helm для gitlab**
	1. helm repo add gitlab https://charts.gitlab.io
	2. helm repo update
4.  **Создание namespace**
	1. kubectl create namespace gitlab
5. **Установка GitLab**
	2. Создать values.yml со следующим содержимым:
	   ``` shell
	global:
  hosts:
    domain: 1.1.1.1  # Замените на ip ingress
  ingress:
    configureCertmanager: true
  psql:
    password:
      secret: gitlab-postgresql-password
      key: postgresql-password
gitlab:
  webservice:
    replicas: 1
  sidekiq:
    replicas: 1
  gitlab-shell:
    replicas: 1
postgresql:
  install: true
redis:
  install: true
```
	2. helm install gitlab gitlab/gitlab -n gitlab -f values.yaml
	3. kubectl get pods -n gitlab -o wide (для проверки установки по нодам)
6. **Получение доступа к GitLab**:
	1. kubectl get ingress -n gitlab, затем открыть в браузере по внешнему Ip
7.  **Получение root пароля:**
	1. kubectl get secret gitlab-gitlab-initial-root-password -n gitlab -o jsonpath="{.data.password}" | base64 --decode



helm install gitlab gitlab/gitlab \ --set global.hosts.domain=87 \ --set certmanager-issuer.email=me@example.com