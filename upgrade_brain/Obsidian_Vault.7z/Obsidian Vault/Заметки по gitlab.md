Установка описана тут (https://about.gitlab.com/install/?version=ce#ubuntu), заменяем ``ee`` на ``ce`` в обязательном порядке:


**Так же возможно установить через docker, compose для установки через docker запушен в git**

Сперва нужно установить докер (curl -fsSL https://get.docker.com -o install-docker.sh)
Нужно установить runner для запуска pipeline, установка runner docker: (https://docs.gitlab.com/runner/install/docker.html)

Регистрация runner (https://docs.gitlab.com/runner/register/index.html?tab=Docker)
Токен для регистрации берется в Project - Settings - Runner


При регистрации могут возникнуть ошибки, особенно если используется самоподписанный сертификат, стартовать в таком случае нужно с указанием пути до этого самоподписанного сертификата (в моем случае использовался сертификат CloudFlare)

```
docker run -d --name gitlab-runner \
  -v /srv/gitlab-runner/config:/etc/gitlab-runner \
  -v /etc/gitlab/ssl/gitlab.mylittledev.ru.crt:/etc/gitlab-runner/certs/gitlab.mylittledev.ru.crt \
  gitlab/gitlab-runner:latest
```

```
docker run --rm -it \
  -v /srv/gitlab-runner/config:/etc/gitlab-runner \
  -v /etc/gitlab/ssl/gitlab.mylittledev.ru.crt:/etc/gitlab-runner/certs/gitlab.mylittledev.ru.crt \
  gitlab/gitlab-runner register \
  --non-interactive \
  --url "https://gitlab.mylittledev.ru/" \
  --registration-token "glrt-t3_QfxiPmbyE5XXziBaLgvx" \
  --executor "docker" \
  --docker-image "ubuntu:20.04" \
  --tls-ca-file "/etc/gitlab-runner/certs/gitlab.mylittledev.ru.crt"
```

От докера отказался из-за проброса сертификатов, установил сервисом, выполнил следующие команды:

`echo -n | openssl s_client -showcerts -connect gitlab.mylittledev.ru:443 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > gitlab.crt` (загрузка корневого CF сертификата)

**Создание директории для сертификата**
sudo mkdir -p /etc/gitlab-runner/certs 
sudo cp gitlab.crt /etc/gitlab-runner/certs/gitlab.mylittledev.ru.crt

**Регистрация runner**
sudo gitlab-runner register \
  --url https://gitlab.mylittledev.ru/ \
  --registration-token "glrt-t3_QfxiPmbyE5XXziBaLgvx" \
  --executor "shell" \
  --docker-image "ubuntu:20.04" \
  --tls-ca-file "/etc/gitlab-runner/certs/gitlab.mylittledev.ru.crt"